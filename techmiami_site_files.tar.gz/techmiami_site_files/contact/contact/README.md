Simple PHP Contact Form
=======================

A Simple Contact Form developed in PHP with HTML5 Form validation. Has a fallback in JavaScript for browsers that do not support HTML5 form validation.

Were developed two forms of form validation, one using jQuery and the other with pure JavaScript. The PHP code for both is the same. choose your and do not forget to change the PHP script where the email should be sent.

```php
$emailTo = '<YOUR_EMAIL_HERE>';
```

See the online form [here](http://www.pinceladasdaweb.com.br/blog/uploads/contact-form/).