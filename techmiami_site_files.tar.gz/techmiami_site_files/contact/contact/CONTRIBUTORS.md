Simple PHP Contact Form contributors (sorted alphabeticaly)
============================================

* **[Matheus Gontijo](https://github.com/matheusgontijo)**

  * Refatored PHP Code

* **[William Bruno](https://github.com/wbruno)**

  * Created a version with VanillaJS

